﻿using Discord.WebSocket;

namespace CodeClawsBot.controllers;

public class UserController
{
    public static void AddUser(SocketUser user)
    {
        
    }
    
    public static void RemoveUser(ulong userId)
    {
        
    }
    
    public static void UpdateUser(ulong userId)
    {
        
    }
    
    public static void GetUser(ulong userId)
    {
        
    }
}