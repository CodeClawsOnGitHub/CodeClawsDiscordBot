﻿using System.Collections.Generic;
using CodeClawsDiscordBot.models;

namespace CodeClawsBot.dataaccessobjects;

public class UserDAO
{
    private Dictionary<string, UserModel> _userCache = new Dictionary<string, UserModel>();
    
    
    public static bool AddUser(UserModel user)
    {
        return false;
    }
    
    public static bool RemoveUser(ulong userId)
    {
        return false;
    }
    
    public static bool UpdateUser(UserModel user)
    {
        return false;
    }

    public static UserModel GetUser(ulong userId)
    {
        return new UserModel();
    }
}