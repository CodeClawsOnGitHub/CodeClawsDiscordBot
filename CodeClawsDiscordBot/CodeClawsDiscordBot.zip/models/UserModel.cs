﻿using System;

namespace CodeClawsDiscordBot.models;
enum Status
{
    Active,
    Inactive,
    Banned,
    Kicked
}

public struct UserModel
{
   
    ulong DiscordId;
    string Name;
    string Discriminator;
    string AvatarURL;
    Status UserStatus;
    DateTime JoinedDate;
    DateTime LastSeenDate;
    DateTime LeaveDate;
    
    
}