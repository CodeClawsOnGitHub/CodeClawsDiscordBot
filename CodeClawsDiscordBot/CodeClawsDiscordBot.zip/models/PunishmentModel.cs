﻿using System;

namespace CodeClawsDiscordBot.models;

enum PunishentType
{
    Warn,
    Timeout,
    Kick,
    Ban,
    Mute
}

public struct PunishmentModel
{
    string PunishmentID;
    ulong UserDiscordId;
    ulong ModeratorDiscordId;
    string Reason;
    DateTime DateOfPunishment;
}